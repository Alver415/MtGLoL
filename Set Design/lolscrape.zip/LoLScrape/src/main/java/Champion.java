import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Champion {

     String id;
     String name;
     Path htmlPath;
     Map<Slot, List<Ability>> abilities = new TreeMap<>();


}
