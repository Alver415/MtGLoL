import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class LoLScrape {

    static final HttpClient httpClient = HttpClient.newHttpClient();

    public static void main(String... args) {
        queryAllChampions().stream()
                .map(LoLScrape::scrapeChampionInfo)
                .forEach(LoLScrape::save);
    }

    private static List<Champion> queryAllChampions() {
        Champion shaco = new Champion();
        shaco.id = "Shaco";
        return List.of(shaco);
    }

    private static Champion scrapeChampionInfo(Champion champion) {
        try {
            URI uri = new URI("https://leagueoflegends.fandom.com/wiki/%s/LoL".formatted(champion.id));
            HttpRequest request = HttpRequest.newBuilder(uri).GET().build();

            HttpResponse<Path> response = httpClient.send(request, HttpResponse.BodyHandlers.ofFile(Path.of("output").resolve(champion.id)));
            champion.htmlPath = response.body();

            return champion;

        } catch (URISyntaxException | IOException | InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    private static void save(Champion champion) {
        try {
            Path file = Path.of("output").resolve(champion.id);
            Files.createDirectories(file.getParent());
            Files.writeString(file, serialize(champion));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private static String serialize(Champion champion) {
        return champion.toString();
    }
}
