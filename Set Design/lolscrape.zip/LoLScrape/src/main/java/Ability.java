

public class Ability {
    String name;
    String description;
}