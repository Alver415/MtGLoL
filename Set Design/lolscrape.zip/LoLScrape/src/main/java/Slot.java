
public enum Slot {
    P, Q, W, E, R;
}