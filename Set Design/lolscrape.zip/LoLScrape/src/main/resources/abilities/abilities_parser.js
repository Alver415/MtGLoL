//https://www.mobafire.com/league-of-legends/abilities

var list = $(".ability-list__item")
function getChampionName(item) {
    return $(item).find("img")[0].attributes.champ.value;
}
function getAbilityKey(item) {
    var key = $(item).find(".ability-list__item__keybind")[0].innerText;
    return key ? key : 'P';
}

function getAbilityName(item) {
    var child = $(item).find(".ability-list__item__name")[0].firstChild;
    var texts = [];

    while (child) {
        if (child.nodeType === 3) {
            texts.push(child.data.trim());
        }
        child = child.nextSibling;
    }
    return texts.join("");
}

function getAbilityDescription(item) {
    var child = $(item).find(".ability-list__item__name")[0].firstChild;
    var texts = [];

    while (child) {
        if (child.nodeType !== 3) {
            texts.push(child.innerText);
        }
        child = child.nextSibling;
    }
    return texts.join("");
}

function toJson(list) {
    var map = {};
    for (var i in list) {
        try {
            var item = list[i];
            var championName = getChampionName(item);
            var abilityKey = getAbilityKey(item);
            var abilityName = getAbilityName(item);
            var abilityDescription = getAbilityDescription(item);
            if (map[championName] == null) {
                map[championName] = {
                    P:[], Q:[], W:[], E:[], R:[],
                };
            }
            var champion = map[championName];
            champion[abilityKey].push({
                abilityName: abilityName,
                abilityDescription: abilityDescription,
            });
        } catch (e) {
            console.log(e);
            break;
        }
    }
    console.log(map)
    return map;
}