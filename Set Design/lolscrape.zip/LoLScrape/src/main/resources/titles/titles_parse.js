
var map = {};
var current = first;
while (current){
    try {
        var fullName = $(current)[0].firstChild.nextSibling.innerText.replace("\n", ", ");
        var name = fullName.split(", ")[0];
        var title = fullName.split(", ")[1];
        map[name] = {
            fullName: fullName,
            title: title
        }
    } catch (e){
        console.log(e);
    }
    current = current.nextSibling.nextSibling;
}