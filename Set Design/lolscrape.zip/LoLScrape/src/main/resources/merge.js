
const fs = require('fs');

function nameToId(name) {
    return name.toLowerCase().replace(/ /g, "_").replace(/[^_a-zA-Z0-9]/g, '');
}

let titleMap = JSON.parse(fs.readFileSync('src/main/resources/titles/titles.json'));
let abilityMap = JSON.parse(fs.readFileSync('src/main/resources/abilities/abilities.json'));
let champs = {};

for (var name in titleMap){
    var champId = nameToId(name);
    champs[champId] = titleMap[name];
    var abilities = abilityMap[name];
    var champ = champs[champId];
    champ.id = champId;
    champ.name = name;
    champ.abilities = abilities;
}


console.log(champs);

fs.writeFile('src/main/resources/champions.json', JSON.stringify(champs, null, 2), (err) => {
    if (err) throw err;
    console.log('Success');
});

